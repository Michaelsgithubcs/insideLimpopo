# Code Citations

## License: unknown
https://github.com/mikenson/mikenson.github.io/tree/7a9539793d781575d6c56f66b185042ee05079ff/Project/personalweb.html

```
"stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
    />
    <link
      href="https://fonts.googleapis.
```


## License: unknown
https://github.com/Rahat019/ssjunior/tree/e0167f356b3a601b2c855e6b1403f0137aec10fd/index.html

```
<link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
    />
    <link
      href="https://
```


## License: unknown
https://github.com/shanmd975/Snap-deal-clone-project/tree/55edcdbdc1b486474426c058ede8e0fed3416218/product.html

```
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
    />
    <link
      href="https://fonts.googleapis.com/css2
```


## License: unknown
https://github.com/bjarte1234567/JS2-CA/tree/ce59e1f4f789a70d386d24800517f44f8fcdc279/index.html

```
//cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"
    />
    <link
      href="https://fonts.googleapis.com/css2?family=Playfair+
```

